/*
 * cli.h
 *
 *  Created on: 14 de mai de 2019
 *      Author: alex
 */

#ifndef CLI_H_
#define CLI_H_

#include <Arduino.h>

void cli_init();

#endif /* CLI_H_ */
